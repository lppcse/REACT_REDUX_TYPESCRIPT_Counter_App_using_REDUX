import { combineReducers } from 'redux';
import  CounterReducer from './Reducers/Counter.reducers';

const rootReducer = combineReducers({
    counter: CounterReducer
});

export default rootReducer;
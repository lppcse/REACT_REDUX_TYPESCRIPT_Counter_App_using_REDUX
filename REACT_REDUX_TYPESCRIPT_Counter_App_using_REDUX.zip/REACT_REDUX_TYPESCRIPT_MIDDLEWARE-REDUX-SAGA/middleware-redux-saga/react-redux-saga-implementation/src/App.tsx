import React from 'react';
import logo from './logo.svg';
import './App.css';

import { connect } from 'react-redux';
import { increaseCounter, decreaseCounter } from './redux/Actions/Counter.actions';

function App(props: any) {
  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
          Edit <code>src/App.tsx</code> and save to reload.
        </p>
        <div>Count: {props && props.count}</div>
     <button onClick={() => props.increaseCounter()}>Increase        Count</button>
     <button onClick={() => props.decreaseCounter()}>Decrease Count</button>
      </header>
    </div>
  );
}

const mapStateToProps = (state: any) => {
  return {
     count: state.count,
   };
  };
  const mapDispatchToProps = (dispatch: any) => {
  return {
     increaseCounter: () => dispatch(increaseCounter()),
     decreaseCounter: () => dispatch(decreaseCounter()),
    };
  };


export default connect(mapStateToProps, mapDispatchToProps)(App);
